package com.belafon.zapoctovy_program.Game.Map;

/**
 * Created by ticha on 07.12.2020.
 */

public class Forest extends TypeOfPlace {
}
