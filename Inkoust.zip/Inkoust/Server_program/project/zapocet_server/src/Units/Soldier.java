package Units;

import Game.Player;

public class Soldier extends Unit{
	public static final int vision = 1;
	public Soldier(Player player, int positionX, int positionY, int id) {
		super(player, positionX, positionY, vision, id);
		// TODO Auto-generated constructor stub
	}

}
